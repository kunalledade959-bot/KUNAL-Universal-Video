package com.kunal.universalvideo

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class UniversalAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: UniversalAccessibilityService? = null
        @Volatile var targetPackage: String = ""
        @Volatile var targetForeground: Boolean = false
        @Volatile var isEnabled: Boolean = false

        fun launchPackage(c: Context, p: String): Boolean {
            val intent = c.packageManager.getLaunchIntentForPackage(p) ?: return false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            c.startActivity(intent)
            return true
        }

        fun clickText(t: String): Boolean = instance?.clickTextInternal(t) ?: false
        fun setFocusedText(t: String): Boolean = instance?.setTextInternal(t) ?: false
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        isEnabled = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val packageName = event?.packageName?.toString() ?: return
        targetForeground = targetPackage.isNotBlank() && packageName == targetPackage

        runCatching {
            TargetGuideManager.captureUiEvidence(applicationContext, rootInActiveWindow)
        }
        runCatching {
            AutonomousWorkflowLearner.discover(applicationContext, packageName, rootInActiveWindow)
        }
        runCatching {
            AudioAssetIntelligence.discoverInstalledProviders(applicationContext)
        }
    }

    override fun onInterrupt() {
        targetForeground = false
    }

    override fun onDestroy() {
        targetForeground = false
        isEnabled = false
        instance = null
        super.onDestroy()
    }

    private fun clickTextInternal(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (node in root.findAccessibilityNodeInfosByText(t)) {
            if (node.isClickable) {
                return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            var parent = node.parent
            while (parent != null) {
                if (parent.isClickable) {
                    return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                parent = parent.parent
            }
        }
        return false
    }

    private fun setTextInternal(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle()
        args.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
            t
        )
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }
}
