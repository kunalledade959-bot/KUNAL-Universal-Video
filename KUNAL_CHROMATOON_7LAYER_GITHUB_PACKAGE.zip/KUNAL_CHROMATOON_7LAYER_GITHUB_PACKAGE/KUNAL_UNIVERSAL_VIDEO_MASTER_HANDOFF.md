# KUNAL UNIVERSAL VIDEO — MASTER HANDOFF

## PURPOSE
This file is the master context for the next chat. Continue the KUNAL Universal Video project from here without making the user repeat the history.

Rules:
- User only wants to install/test the final APK on the phone.
- Do not repeatedly ask for permission or technical choices.
- Do not send repeated Kaggle repair cells.
- Do not fake PASS, READY, or APK.
- Diagnose actual errors and fix them yourself whenever technically possible.
- Ask the user only when a genuinely user-only action is required.

## PROJECT GOAL
Build a ready-to-use Android APK named KUNAL Universal Video.

Workflow:
Story input -> target APK selection -> target-app study -> story/scene/character/voice planning -> automatic target-app operation -> recording -> clip/audio assembly -> final editing -> verification/auto-fix -> gallery export.

First target app: Chromatoon.

## LOCKED FUNCTION ORDER

1. APK Startup / Self-Diagnostic
- Health check on startup.
- Detect missing/error components.
- Automatically repair/reinitialize recoverable issues.
- Fatal issue: exact error + export/log option.
- Never fake PASS.

2. Mobile Connection / Permissions
- Request required permissions.
- CONNECT button.
- DISCONNECT button.
- Real Connected/Disconnected state.

3. Target APK Selection
- User selects the target APK.
- Selection MUST happen before target-app video logic.

4. Study Selected APK
- Inspect selected APK.
- Understand how it creates videos.
- Read/use available user guide/help.
- Understand UI, controls, characters, backgrounds, motion, audio, export, etc.

5. Story Input
- Story text box.
- User can state requested duration/details.

6. Story -> Production Plan / Audio
- Decide characters, scenes, timing, prompts.
- Generate required dialogue/narration.
- Free/original voices where possible.
- Situation- and character-appropriate voices.
- Safe/free/original music and SFX where possible.

7. Deep Target-App Understanding
- Use guide + actual UI interaction.
- Understand controls and manual workflow.
- Learn best way to make the requested video.

8. Exact Scene Plan
- Character count.
- Voice count.
- Scene count.
- Clip durations.
- Backgrounds.
- Motions/actions.
- Audio placement.
- If a long clip fails, split into smaller clips.

9. Operate Target APK
- Open selected target.
- Create scenes according to plan.
- Use characters/backgrounds/motions/audio.
- Retry/re-detect/split when needed.
- Preserve scene continuity.

10. Assemble/Edit
- Correct clip order.
- Correct dialogue/voice placement.
- Music/SFX placement.
- Timing.
- Merge/edit complete video.

11. Verify/Auto-Fix
- Check scenes, order, duration, audio, missing clips, playability, recording.
- Automatically retry/fix/re-record/rebuild where possible.
- Never stop unnecessarily.

12. Gallery Export
- Save finished video to phone gallery.

## SCREEN RECORDING REQUIREMENT
Chromatoon may require screen recording.
If Chromatoon's recorder fails, automatically use Android MediaProjection/mobile screen recording as fallback where technically possible.
Recording must start/stop correctly and be processed into the final video.

## SELF-RECOVERY
Handle recoverable failures automatically:
- reinitialize services
- reset temporary state/cache
- retry operation
- reopen target app
- re-detect UI
- retry scene
- split scene
- restart recording
- rebuild final video
- restore checkpoints/state where practical.

Unrecoverable errors must be reported exactly; no fake success.

## TECHNICAL ROUTE
Preferred approach is NOT endless patching of the broken APK.

Use proven open-source Android building blocks where license/compatibility permits:
- MobileAgent-Android: Accessibility/UI detection, screenshots, tap/swipe/type, multi-step automation, replanning/recovery.
- FadCam: screen-recording subsystem candidate.
- LibreCuts/FFmpeg-style media pipeline: editing/assembly candidate, subject to license/integration review.
- Open-AutoGLM-Android was investigated but should not automatically be primary because standard setup can require external model/API/network dependencies.

Integrate the automation layer with the existing KUNAL workflow.

## AUTHORITATIVE SOURCE
Previous authoritative master source:
`/kaggle/input/datasets/kunalledade/kunal-universal-video-master/KUNAL_UNIVERSAL_VIDEO_MASTER.py`

Other important project artifacts:
- KUNAL_UV_V9_FINAL.zip
- KUNAL_UV_FINAL.apk (existing/old build; NOT a newly rebuilt APK)

Never describe the old APK as a new repaired build.

## PREVIOUS BUILD FAILURE
A previous one-cell Kaggle build failed before APK compilation because of a Python indentation error around line ~198. A closing `]` had incorrect indentation.

This was a generated-code mistake, not the user's mistake.

Before giving code:
- syntax/compile-check it.
- Do not claim PASS merely because code prints PASS.

## BUILD REQUIREMENT
User wants:
- one cell maximum if Kaggle is unavoidable.
- no second repair cell.
- automatic recovery built into the process.
- user should not manually fix build errors.
- no fake APK.
- no fake PASS.
- final APK must actually be built/verified.
- user performs only final mobile test.

Preferred route now: remote/connected Android build instead of repeated Kaggle cells.

## GITHUB STATUS — CURRENT
GitHub is NOW genuinely connected.

A live GitHub profile check succeeded through the connected GitHub tool.

Authenticated profile observed:
- nickname/login: `kunalledade959-bot`

GitHub tools available include:
- list/search repositories
- fetch/search files
- create/update files
- create branches/commits
- inspect GitHub Actions
- fetch workflow jobs/logs
- rerun failed jobs
- fetch/download workflow artifacts.

Therefore GitHub Actions is the preferred remote Android build route.

## IMMEDIATE NEXT STEPS
Do these without asking the user to choose:

1. List accessible GitHub repositories.
2. Find KUNAL / Universal Video / KUNAL_UV repository or source.
3. Inspect structure, branches, build files, existing workflows.
4. If source is in GitHub, prepare/repair Android build workflow.
5. Workflow should:
   - checkout
   - setup JDK
   - setup Android SDK
   - setup Gradle
   - build APK
   - locate APK
   - structurally verify APK
   - upload APK as artifact.
6. Run build.
7. If it fails, inspect actual logs, diagnose root cause, edit source/workflow, commit, rerun. Do not ask user to debug.
8. After successful build, verify:
   - build exit success
   - APK exists/non-empty
   - APK ZIP readable
   - AndroidManifest.xml exists
   - classes.dex exists
   - package metadata where possible
   - artifact exists.
9. Retrieve artifact if connector supports it.
10. Only then call it BUILD VERIFIED / MOBILE TEST PENDING.

## IMPORTANT LIMITATION
Previous local runtime lacked a complete Android SDK/Gradle environment and had internet/DNS restrictions. It could not honestly build the new APK there.

GitHub is now connected, so use GitHub Actions/remote CI.

Do not say a new APK was built until an actual CI build succeeds and its APK artifact is verified.

## USER COMMUNICATION
User has spent many days in repeated build/debug loops and is frustrated.

Keep responses:
- concise
- action-oriented
- no unnecessary theory
- no repeated questions
- no repeated permission requests
- make technical decisions independently.

Still be completely truthful about verification.

## FINAL PRODUCT REQUIREMENTS
The APK must ultimately provide:
1. Startup self-diagnostic
2. Automatic recoverable error repair
3. Exact fatal-error reporting/export
4. Mobile connection permissions
5. Connect button
6. Disconnect button
7. Real connection state
8. Target APK selector
9. Target APK inspection
10. User-guide/help understanding
11. Story input
12. Duration input
13. Story analysis
14. Character planning
15. Scene planning
16. Voice planning
17. Free/original voice generation where possible
18. Situation-appropriate voices
19. Background planning
20. Motion/action planning
21. Target-app automation
22. Clip splitting when needed
23. Clip continuity/merging
24. Audio/music/SFX placement
25. Final editing
26. Verification
27. Automatic fixing/retry
28. Chromatoon recorder support
29. Android MediaProjection fallback
30. Gallery export
31. Recoverable state/checkpoints where practical
32. Real diagnostics/logs
33. No fake PASS

## FIRST TARGET
Chromatoon is the first real target.
The system should eventually support other target APKs, but Chromatoon is the first test.

## USER-ONLY ACTION
User should not:
- edit Python
- add repair cells
- install Android Studio
- configure Gradle/SDK
- edit Java/Kotlin
- manually assemble scenes.

User will:
- install APK
- grant Android permissions when Android asks
- connect/select target APK as needed
- test final workflow
- report real phone-side results.

## VERIFICATION STANDARD
Do not call something:
- APK READY
- PASS
- WORKING
- FIXED

unless actual evidence supports it.

Build verification:
- successful CI build
- verified APK artifact
- APK structural checks
- artifact retrievable.

Device behavior remains MOBILE TEST PENDING until user tests the phone.

## NEW CHAT START MESSAGE
If needed, paste:
"Continue KUNAL Universal Video from the attached MASTER HANDOFF. GitHub is already connected. Do not ask me to repeat requirements or run repair cells. Inspect the GitHub repositories, locate the KUNAL source, set up the Android CI build, fix actual build errors yourself, verify the APK, and deliver the real APK. I will only install and test it on my phone. No fake PASS and no fake APK."

## END STATE
Phase completion:
REAL APK ARTIFACT -> BUILD VERIFIED -> DELIVERED -> USER INSTALLS/TESTS.

Ultimate goal:
USER ENTERS STORY -> KUNAL SELECTS/UNDERSTANDS TARGET APP -> KUNAL CREATES VIDEO AUTOMATICALLY -> RECORDING FALLBACK IF NEEDED -> EDITS/ASSEMBLES -> VERIFIES -> SAVES FINAL VIDEO TO GALLERY.
