package com.kunal.universalvideo

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import org.json.JSONObject
import java.io.File
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.security.MessageDigest
import java.util.UUID

/**
 * Safe, app-private self-healing layer.
 *
 * It repairs recoverable runtime state/configuration only.
 * It never attempts to modify the installed APK, bypass Android security,
 * enable Accessibility/MediaProjection without user consent, or change
 * another application's data.
 */
object SelfRepairManager {
    private const val DIR = "self-repair"
    private const val STATE = "state.json"
    private const val REPORT = "health.json"
    private const val PROTOCOL_ASSET = "repair_protocol.json"
    private const val CRASH = "last_crash.txt"
    private const val SESSION = "session_id"
    private const val TARGET = "target_package"

    data class Health(
        val ok: Boolean,
        val repaired: Boolean,
        val issues: List<String>,
        val repairedItems: List<String>
    )

    @Volatile private var lastHealth = Health(true, false, emptyList(), emptyList())

    fun initialize(context: Context): Health {
        val app = context.applicationContext
        return synchronized(this) {
            try {
                val h = repairAndCheck(app)
                installCrashGuard(app)
                lastHealth = h
                h
            } catch (t: Throwable) {
                // Emergency-safe path: reset only our own transient state.
                val repaired = mutableListOf<String>()
                try {
                    File(app.filesDir, DIR).mkdirs()
                    File(app.filesDir, "$DIR/$STATE").delete()
                    repaired += "reset_corrupt_self_repair_state"
                } catch (_: Throwable) {}
                val h = Health(false, repaired.isNotEmpty(),
                    listOf("self-repair manager exception: ${t.javaClass.simpleName}"),
                    repaired)
                lastHealth = h
                h
            }
        }
    }

    fun health(context: Context): Health = initialize(context)

    /**
     * Executes only predefined safe repair actions.
     * Arbitrary code, shell commands, APK replacement, and security bypasses are forbidden.
     */
    fun applyRepairCode(context: Context, code: String): Health {
        val action = when (code.trim().uppercase()) {
            "KUV-REPAIR-STATE" -> "state"
            "KUV-REPAIR-PROTOCOL" -> "protocol"
            "KUV-REPAIR-SESSION" -> "session"
            "KUV-REPAIR-BRIDGE" -> "bridge"
            else -> return Health(false, false,
                listOf("invalid_or_unsupported_repair_code"), emptyList())
        }
        val app = context.applicationContext
        val prefs = app.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        val repaired = mutableListOf<String>()
        return synchronized(this) {
            try {
                val root = File(app.filesDir, DIR)
                root.mkdirs()
                when (action) {
                    "state" -> {
                        File(root, STATE).delete()
                        File(root, REPORT).delete()
                        repaired += "reset_app_private_repair_state"
                    }
                    "protocol" -> {
                        val dst = File(root, "protocol.json")
                        app.assets.open(PROTOCOL_ASSET).use { input ->
                            dst.outputStream().use { output -> input.copyTo(output) }
                        }
                        repaired += "restored_bundled_protocol"
                    }
                    "session" -> {
                        prefs.edit().putString(SESSION, UUID.randomUUID().toString()).apply()
                        repaired += "regenerated_session"
                    }
                    "bridge" -> {
                        File(root, "transient").deleteRecursively()
                        repaired += "cleared_bridge_transient_state"
                    }
                }
                val result = repairAndCheck(app)
                result.copy(repaired = true, repairedItems = repaired + result.repairedItems)
            } catch (t: Throwable) {
                Health(false, false,
                    listOf("repair_code_action_failed:${t.javaClass.simpleName}"), repaired)
            }
        }
    }

    fun reportJson(context: Context): JSONObject {
        val h = health(context)
        return JSONObject().apply {
            put("ok", h.ok)
            put("repaired", h.repaired)
            put("issues", org.json.JSONArray(h.issues))
            put("repaired_items", org.json.JSONArray(h.repairedItems))
            put("apk_immutable", true)
            put("android_sdk", Build.VERSION.SDK_INT)
        }
    }

    private fun repairAndCheck(app: Context): Health {
        val issues = mutableListOf<String>()
        val repaired = mutableListOf<String>()
        val root = File(app.filesDir, DIR)
        if (!root.exists() && !root.mkdirs()) {
            issues += "cannot_create_private_repair_directory"
            return Health(false, false, issues, repaired)
        }

        // Repair our own state if it is malformed.
        val stateFile = File(root, STATE)
        val prefs = app.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
        var session = prefs.getString(SESSION, null)
        if (session.isNullOrBlank() || runCatching { UUID.fromString(session) }.isFailure) {
            session = UUID.randomUUID().toString()
            prefs.edit().putString(SESSION, session).apply()
            repaired += "regenerated_invalid_session_id"
        }

        // Remove only an invalid/stale target selection. Never select a target implicitly.
        val target = prefs.getString(TARGET, "") ?: ""
        if (target.isNotBlank()) {
            runCatching { TargetGuideManager.inspectTarget(app, target) }
                .onFailure { issues += "target_guide_inspection_failed:${it.javaClass.simpleName}" }
            val installed = runCatching {
                app.packageManager.getApplicationInfo(target, 0)
                app.packageManager.getLaunchIntentForPackage(target) != null
            }.getOrDefault(false)
            if (!installed) {
                prefs.edit().remove(TARGET).apply()
                UniversalAccessibilityService.targetPackage = ""
                repaired += "cleared_missing_target_package"
            } else {
                UniversalAccessibilityService.targetPackage = target
            }
        }

        // Restore a known-good protocol copy into app-private storage.
        val protocolOut = File(root, "protocol.json")
        val protocolBytes = runCatching {
            app.assets.open(PROTOCOL_ASSET).use { it.readBytes() }
        }.getOrNull()
        if (protocolBytes == null) {
            issues += "bundled_protocol_asset_missing"
        } else {
            val current = protocolOut.takeIf { it.isFile }?.readBytes()
            if (current == null || !current.contentEquals(protocolBytes)) {
                protocolOut.writeBytes(protocolBytes)
                repaired += "restored_protocol_config"
            }
            runCatching {
                JSONObject(String(protocolBytes, Charsets.UTF_8))
            }.onFailure { issues += "bundled_protocol_invalid_json" }
        }

        // Validate our declared services without attempting to enable them.
        val pm = app.packageManager
        val services = runCatching {
            pm.getPackageInfo(
                app.packageName,
                PackageManager.GET_SERVICES
            ).services?.map { it.name }.orEmpty()
        }.getOrDefault(emptyList())

        val requiredServices = listOf(
            UniversalAccessibilityService::class.java.name,
            ScreenCaptureService::class.java.name,
            ControllerBridgeForegroundService::class.java.name
        )
        for (s in requiredServices) {
            if (!services.contains(s)) issues += "declared_service_missing:$s"
        }

        // Verify our own package identity.
        val packageOk = runCatching {
            app.packageName == "com.kunal.universalvideo"
        }.getOrDefault(false)
        if (!packageOk) issues += "unexpected_package_identity"

        // Validate that the LAN port is not permanently blocked by another local owner.
        // A busy port is reported, not forcibly killed.
        if (BridgeHolder.get() == null) {
            runCatching {
                ServerSocket().use { sock ->
                    sock.reuseAddress = true
                    sock.bind(InetSocketAddress("127.0.0.1", LocalBridgeService.PORT))
                }
            }.onFailure {
                issues += "bridge_port_unavailable:${LocalBridgeService.PORT}"
            }
        }

        // Validate accessibility state as information only.
        val enabled = runCatching {
            val am = app.getSystemService(Context.ACCESSIBILITY_SERVICE)
                as android.view.accessibility.AccessibilityManager
            am.getEnabledAccessibilityServiceList(
                AccessibilityServiceInfo.FEEDBACK_ALL_MASK
            ).any {
                it.resolveInfo?.serviceInfo?.packageName == app.packageName
            }
        }.getOrDefault(false)
        if (!enabled) issues += "accessibility_requires_user_enable"

        // Persist a small machine-readable state/report for diagnostics.
        stateFile.writeText(
            JSONObject(mapOf(
                "session_id" to session,
                "target_package" to (prefs.getString(TARGET, "") ?: ""),
                "protocol_file" to protocolOut.absolutePath
            )).toString(),
            Charsets.UTF_8
        )

        val health = Health(issues.none { !it.startsWith("accessibility_requires_user_enable") },
            repaired.isNotEmpty(), issues, repaired)
        File(root, REPORT).writeText(
            JSONObject(mapOf(
                "ok" to health.ok,
                "repaired" to health.repaired,
                "issues" to org.json.JSONArray(health.issues),
                "repaired_items" to org.json.JSONArray(health.repairedItems),
                "timestamp_ms" to System.currentTimeMillis()
            )).toString(),
            Charsets.UTF_8
        )
        return health
    }

    private fun installCrashGuard(app: Context) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        if (previous is CrashGuard) return
        Thread.setDefaultUncaughtExceptionHandler(
            CrashGuard(app, previous)
        )
    }

    private class CrashGuard(
        private val app: Context,
        private val previous: Thread.UncaughtExceptionHandler?
    ) : Thread.UncaughtExceptionHandler {
        override fun uncaughtException(thread: Thread, throwable: Throwable) {
            runCatching {
                val root = File(app.filesDir, DIR)
                root.mkdirs()
                File(root, CRASH).writeText(
                    "${throwable.javaClass.name}: ${throwable.message ?: ""}",
                    Charsets.UTF_8
                )
                // Delete only transient bridge state; persistent target selection remains.
                File(root, "transient").deleteRecursively()
            }
            previous?.uncaughtException(thread, throwable)
                ?: runCatching { android.os.Process.killProcess(android.os.Process.myPid()) }
        }
    }
}
