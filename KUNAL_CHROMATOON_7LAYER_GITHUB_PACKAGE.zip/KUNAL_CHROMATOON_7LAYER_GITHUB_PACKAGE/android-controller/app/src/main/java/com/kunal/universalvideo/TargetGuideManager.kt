package com.kunal.universalvideo

import android.content.Context
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Evidence-based target-app guide/workflow layer.
 * It never invents unknown controls.
 */
object TargetGuideManager {
    private const val DIR="guide-knowledge"
    private const val GUIDE="target_guide.json"
    private const val UI_MAP="ui_map.json"
    private const val WORKFLOWS="workflows.json"

    fun inspectTarget(context: Context, packageName: String): JSONObject {
        val pm=context.packageManager
        val ai=pm.getApplicationInfo(packageName,0)
        val pi=pm.getPackageInfo(packageName,0)
        val version=if(android.os.Build.VERSION.SDK_INT>=28) pi.longVersionCode else pi.versionCode.toLong()
        val root=File(context.filesDir,DIR).apply{mkdirs()}
        val out=JSONObject()
            .put("package",packageName)
            .put("label",pm.getApplicationLabel(ai).toString())
            .put("version_name",pi.versionName ?: "unknown")
            .put("version_code",version)
            .put("guide_status",if(File(root,GUIDE).isFile) "GUIDE_AVAILABLE" else "GUIDE_NOT_SUPPLIED")
            .put("workflow_status",workflowStatus(root,packageName,pi.versionName ?: "unknown"))
            .put("policy","never_invent_unknown_controls")
        File(root,"target.json").writeText(out.toString(2),Charsets.UTF_8)
        return out
    }

    private fun workflowStatus(root:File,pkg:String,version:String):String{
        val f=File(root,WORKFLOWS)
        if(!f.isFile)return "NO_RECORDED_WORKFLOW"
        return runCatching{
            val a=JSONArray(f.readText())
            for(i in 0 until a.length()){
                val o=a.getJSONObject(i)
                if(o.optString("package")==pkg && o.optString("version_name")==version)
                    return@runCatching "RECORDED_WORKFLOW_AVAILABLE"
            }
            "NO_VERSION_MATCH"
        }.getOrDefault("WORKFLOW_FILE_INVALID")
    }

    fun captureUiEvidence(context:Context,rootNode:AccessibilityNodeInfo?){
        if(rootNode==null)return
        val nodes=JSONArray()
        fun walk(n:AccessibilityNodeInfo?,depth:Int){
            if(n==null||depth>40)return
            nodes.put(JSONObject()
                .put("class",n.className?.toString()?:"")
                .put("text",n.text?.toString()?:"")
                .put("content_desc",n.contentDescription?.toString()?:"")
                .put("view_id",n.viewIdResourceName?:"")
                .put("clickable",n.isClickable)
                .put("enabled",n.isEnabled)
                .put("scrollable",n.isScrollable))
            for(i in 0 until n.childCount)walk(n.getChild(i),depth+1)
        }
        walk(rootNode,0)
        val d=File(context.filesDir,DIR).apply{mkdirs()}
        File(d,UI_MAP).writeText(JSONObject().put("evidence_only",true).put("nodes",nodes).toString(2),Charsets.UTF_8)
    }

    fun saveConfirmedWorkflow(context:Context,packageName:String,versionName:String,steps:JSONArray){
        val d=File(context.filesDir,DIR).apply{mkdirs()}
        val f=File(d,WORKFLOWS)
        val a=runCatching{JSONArray(if(f.isFile)f.readText() else "[]")}.getOrDefault(JSONArray())
        a.put(JSONObject().put("package",packageName).put("version_name",versionName)
            .put("steps",steps).put("confirmed_by_user",true).put("evidence_only_execution",true))
        f.writeText(a.toString(2),Charsets.UTF_8)
    }

    fun importGuide(context:Context,guideText:String,source:String){
        require(guideText.trim().isNotEmpty())
        val d=File(context.filesDir,DIR).apply{mkdirs()}
        File(d,GUIDE).writeText(JSONObject().put("source",source)
            .put("content",guideText.trim()).put("imported_at_ms",System.currentTimeMillis()).toString(2),Charsets.UTF_8)
    }
}
