package com.kunal.universalvideo

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.Inet4Address
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.random.Random
import java.util.UUID

class LocalBridgeService(
    private val context: Context,
    private val sessionId: String,
    private val callback: (String) -> Unit
) {
    companion object { const val PORT = 8765 }

    private val running = AtomicBoolean(false)
    private val paired = AtomicBoolean(false)
    private var pairingCode = Random.nextInt(100000, 1000000).toString()
    @Volatile private var failedPairAttempts = 0
    @Volatile private var lockUntilMs = 0L
    @Volatile private var server: ServerSocket? = null
    @Volatile private var target = ""
    @Volatile private var authToken = ""
    private val pool = Executors.newCachedThreadPool()

    fun start() {
        if (!running.compareAndSet(false, true)) return
        pool.execute {
            try {
                server = ServerSocket(PORT, 32, java.net.InetAddress.getByName("0.0.0.0"))
                callback("Bridge listening on ${localIp()}:$PORT")
                while (running.get()) {
                    try {
                        val socket = server?.accept() ?: break
                        pool.execute { handle(socket) }
                    } catch (_: SocketException) {
                        if (running.get()) callback("Bridge socket error")
                    }
                }
            } catch (e: Exception) {
                callback("Bridge failed: ${e.javaClass.simpleName}: ${e.message ?: "unknown"}")
                running.set(false)
            }
        }
    }

    fun isRunning(): Boolean = running.get()
    fun currentPairingCode(): String = pairingCode
    fun localAddress(): String = localIp()

    fun prepareTarget(packageName: String): Boolean {
        if (packageName.isBlank()) return false
        val launch = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
        target = packageName
        UniversalAccessibilityService.targetPackage = packageName
        return launch != null
    }

    fun disconnect() {
        paired.set(false)
        authToken = ""
        pairingCode = newPairingCode()
        callback("Disconnected — new pairing code: $pairingCode")
    }

    private fun newPairingCode(): String = Random.nextInt(100000, 1000000).toString()

    fun stop() {
        running.set(false)
        paired.set(false)
        try { server?.close() } catch (_: Exception) {}
        server = null
        pool.shutdownNow()
    }

    private fun handle(socket: Socket) {
        socket.use { s ->
            s.soTimeout = 8000
            val input = s.getInputStream()
            val headerBuffer = java.io.ByteArrayOutputStream()
            val marker = byteArrayOf(13, 10, 13, 10)
            var matched = 0
            while (headerBuffer.size() < 65536) {
                val b = input.read()
                if (b < 0) return
                headerBuffer.write(b)
                if (b.toByte() == marker[matched]) {
                    matched++
                    if (matched == marker.size) break
                } else {
                    matched = if (b.toByte() == marker[0]) 1 else 0
                }
            }
            val headerText = headerBuffer.toByteArray().toString(Charsets.ISO_8859_1)
            val headerParts = headerText.split("\r\n")
            val requestHeaders = headerParts.drop(1).filter { it.contains(":") }.associate {
                val k = it.substringBefore(":").trim().lowercase()
                val v = it.substringAfter(":").trim()
                k to v
            }
            val requestLine = headerParts.firstOrNull() ?: return
            val parts = requestLine.split(" ")
            val method = parts.getOrNull(0)?.uppercase() ?: "GET"
            val path = parts.getOrNull(1)?.substringBefore("?") ?: "/"
            var contentLength = 0
            for (header in headerParts.drop(1)) {
                if (header.isBlank()) continue
                if (header.lowercase().startsWith("content-length:")) {
                    contentLength = header.substringAfter(":").trim().toIntOrNull() ?: 0
                }
            }
            val body = if (contentLength in 1..1_000_000) {
                val bytes = ByteArray(contentLength)
                var read = 0
                while (read < contentLength) {
                    val n = input.read(bytes, read, contentLength - read)
                    if (n <= 0) break
                    read += n
                }
                if (read == contentLength) String(bytes, Charsets.UTF_8) else ""
            } else ""
            val token = requestHeaders["x-kuv-session"] ?: ""
            val (status, response) = route(method, path, body, token)
            val bytes = response.toByteArray(Charsets.UTF_8)
            val out = s.getOutputStream()
            out.write(("HTTP/1.1 $status\r\n" +
                "Content-Type: application/json; charset=utf-8\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n" +
                "Access-Control-Allow-Headers: Content-Type, X-KUV-Session\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Connection: close\r\n\r\n").toByteArray())
            out.write(bytes)
            out.flush()
        }
    }

    private fun route(method: String, path: String, body: String, token: String): Pair<String, String> {
        if (method == "OPTIONS") return "204 No Content" to ""
        return when (path) {
            "/health" -> if (method == "GET") "200 OK" to JSONObject(mapOf(
                "ok" to true,
                "protocol" to ControllerProtocol.PROTOCOL,
                "pairing_required" to true,
                "paired" to paired.get(),
                "address" to localIp(),
                "port" to PORT
            )).toString() else "405 Method Not Allowed" to error("GET required")
            "/pair" -> if (method == "POST") pair(body) else "405 Method Not Allowed" to error("POST required")
            "/status" -> if (method == "GET") { if (authorized(token)) "200 OK" to statusJson() else "401 Unauthorized" to error("Valid paired session required") } else "405 Method Not Allowed" to error("GET required")
            "/apps" -> if (method == "GET") { if (authorized(token)) "200 OK" to appsJson() else "401 Unauthorized" to error("Valid paired session required") } else "405 Method Not Allowed" to error("GET required")
            "/command" -> if (method == "POST") command(body, token) else "405 Method Not Allowed" to error("POST required")
            else -> "404 Not Found" to JSONObject(mapOf("ok" to false, "error" to "Not found")).toString()
        }
    }

    private fun pair(body: String): Pair<String, String> {
        val now = System.currentTimeMillis()
        if (now < lockUntilMs) return "429 Too Many Requests" to JSONObject(mapOf("ok" to false, "error" to "Pairing temporarily locked")).toString()
        val supplied = try { JSONObject(body).optString("code", "") } catch (_: Exception) { "" }
        val ok = supplied.length == 6 && supplied == pairingCode
        if (ok) { paired.set(true); failedPairAttempts = 0; authToken = UUID.randomUUID().toString(); pairingCode = newPairingCode() }
        else {
            failedPairAttempts++
            if (failedPairAttempts >= 5) { lockUntilMs = now + 60_000L; failedPairAttempts = 0 }
        }
        val result = JSONObject(mapOf("ok" to ok, "paired" to paired.get()))
        if (ok) result.put("session_token", authToken)
        return (if (ok) "200 OK" else "401 Unauthorized") to result.toString()
    }

    private fun authorized(token: String): Boolean = paired.get() && token.isNotBlank() && token == authToken

    private fun command(body: String, token: String): Pair<String, String> {
        val repair = SelfRepairManager.initialize(context)
        if (!repair.ok && body.contains("PING", ignoreCase = true).not()) {
            return "503 Service Unavailable" to JSONObject(mapOf(
                "ok" to false,
                "error" to "Self-repair check failed",
                "self_repair" to SelfRepairManager.reportJson(context)
            )).toString()
        }
        val obj = try { JSONObject(body) } catch (_: Exception) { return "400 Bad Request" to error("Invalid JSON") }
        val command = obj.optString("command", "").uppercase()
        if (!authorized(token)) {
            return "401 Unauthorized" to error("Valid paired session required")
        }
        return when (command) {
            ControllerProtocol.PING -> "200 OK" to JSONObject(mapOf("ok" to true, "command" to ControllerProtocol.PONG)).toString()
            ControllerProtocol.STATUS -> "200 OK" to statusJson()
            ControllerProtocol.OPEN_TARGET -> {
                val requestedTarget = obj.optString("target_package", target).trim()
                if (requestedTarget.isBlank()) "400 Bad Request" to error("Target not selected")
                else if (!prepareTarget(requestedTarget)) "400 Bad Request" to error("Target package is not installed or cannot be launched")
                else {
                    val launched = UniversalAccessibilityService.launchPackage(context, target)
                    if (launched) "200 OK" to JSONObject(mapOf("ok" to true, "target_package" to target)).toString()
                    else "409 Conflict" to error("Target launch failed")
                }
            }
            ControllerProtocol.RUN_PLAN -> executePlan(obj.optJSONArray("steps") ?: JSONArray())
            ControllerProtocol.START_RECORD -> "409 Conflict" to error("Screen-capture consent must be granted from the phone UI before recording can start")
            ControllerProtocol.STOP_RECORD -> { if (ScreenCaptureService.stopCurrent()) "200 OK" to JSONObject(mapOf("ok" to true)).toString()
                else "409 Conflict" to error("No active recording session") }
            ControllerProtocol.EXPORT_READY -> {
                val ready = ScreenCaptureService.hasSavedOutput()
                if (ready) "200 OK" to JSONObject(mapOf("ok" to true, "ready" to true)).toString()
                else "409 Conflict" to error("No completed video export is available")
            }
            ControllerProtocol.SAVE_GALLERY -> {
                val saved = ScreenCaptureService.hasSavedOutput()
                if (saved) "200 OK" to JSONObject(mapOf("ok" to true, "saved" to true)).toString()
                else "409 Conflict" to error("No completed video is available to save")
            }
            ControllerProtocol.DISCONNECT -> { disconnect(); "200 OK" to JSONObject(mapOf("ok" to true)).toString() }
            else -> "400 Bad Request" to error("Unsupported command")
        }
    }

    private fun executePlan(steps: JSONArray): Pair<String, String> {
        if (steps.length() == 0 || steps.length() > 100) return "400 Bad Request" to error("steps must contain 1..100 actions")
        if (target.isBlank()) return "400 Bad Request" to error("Target not selected")
        val results = JSONArray()
        var allOk = true
        for (i in 0 until steps.length()) {
            val step = steps.optJSONObject(i) ?: return "400 Bad Request" to error("Invalid step at index $i")
            when (step.optString("action").lowercase()) {
                "open_target" -> { val ok = prepareTarget(target) && UniversalAccessibilityService.launchPackage(context, target); results.put(ok); allOk = allOk && ok }
                "wait_ms" -> {
                    val ms = step.optLong("value", -1)
                    if (ms !in 0..30000) return "400 Bad Request" to error("wait_ms must be 0..30000")
                    Thread.sleep(ms)
                    results.put(true)
                }
                "click_text" -> { val ok = UniversalAccessibilityService.clickText(step.optString("value")); results.put(ok); allOk = allOk && ok }
                "set_text" -> { val ok = UniversalAccessibilityService.setFocusedText(step.optString("value")); results.put(ok); allOk = allOk && ok }
                "start_record" -> return "409 Conflict" to error("Recording requires user-granted MediaProjection consent on the phone")
                "stop_record" -> { val ok = ScreenCaptureService.stopCurrent(); results.put(ok); allOk = allOk && ok }
                else -> return "400 Bad Request" to error("Unsupported plan action at index $i")
            }
        }
        return if (allOk) "200 OK" to JSONObject(mapOf("ok" to true, "executed" to results)).toString()
        else "409 Conflict" to JSONObject(mapOf("ok" to false, "executed" to results, "error" to "One or more plan actions failed")).toString()
    }

    private fun appsJson(): String {
        val apps = context.packageManager.queryIntentActivities(
            android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_LAUNCHER), 0
        ).map { info ->
            JSONObject(mapOf("package" to info.activityInfo.packageName, "label" to info.loadLabel(context.packageManager).toString()))
        }.filter { it.optString("package") != context.packageName }
            .distinctBy { it.optString("package") }
            .sortedBy { it.optString("label").lowercase() }
        return JSONObject(mapOf("ok" to true, "apps" to JSONArray(apps))).toString()
    }

    private fun statusJson(): String = JSONObject(mapOf(
        "ok" to true,
        "self_repair" to SelfRepairManager.reportJson(context),
        "protocol" to ControllerProtocol.PROTOCOL,
        "session_id" to sessionId,
        "paired" to paired.get(),
        "target_package" to target,
        "accessibility" to UniversalAccessibilityService.isEnabled,
        "target_foreground" to UniversalAccessibilityService.targetForeground,
        "recording" to ScreenCaptureService.isRecording(),
        "export_ready" to ScreenCaptureService.hasSavedOutput(),
        "address" to localIp(),
        "port" to PORT
    )).toString()

    private fun error(message: String) = JSONObject(mapOf("ok" to false, "error" to message)).toString()

    private fun localIp(): String = try {
        java.net.NetworkInterface.getNetworkInterfaces().toList()
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { it is Inet4Address && !it.isLoopbackAddress && it.isSiteLocalAddress }
            ?.hostAddress ?: "127.0.0.1"
    } catch (_: Exception) { "127.0.0.1" }
}


object BridgeHolder {
    @Volatile private var bridge: LocalBridgeService? = null
    @Synchronized fun start(context: Context, sessionId: String, callback: (String) -> Unit): LocalBridgeService {
        val existing = bridge
        if (existing != null && existing.isRunning()) return existing
        if (existing != null) runCatching { existing.stop() }
        return LocalBridgeService(context.applicationContext, sessionId, callback).also {
            bridge = it
            it.start()
        }
    }
    @Synchronized fun get(): LocalBridgeService? = bridge
    @Synchronized fun stop() {
        bridge?.stop()
        bridge = null
    }
}
