package com.kunal.universalvideo

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import android.os.Handler
import android.os.Looper

class ControllerBridgeForegroundService : Service() {
    private val watchdog = Handler(Looper.getMainLooper())
    private val watchdogTask = object : Runnable {
        override fun run() {
            runCatching {
                BridgeHolder.start(
                    applicationContext,
                    getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                        .getString(MainActivity.SESSION, "") ?: "",
                    {}
                )
            }
            watchdog.postDelayed(this, 15_000L)
        }
    }
    companion object {
        const val START = "START"
        const val STOP = "STOP"
        private const val CHANNEL = "kuv_bridge"
        private const val NOTIFICATION = 8757
    }

    override fun onCreate() {
        super.onCreate()
        SelfRepairManager.initialize(applicationContext)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Controller connection", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Kunal Universal Video")
            .setContentText("Mobile controller connection is active")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setOngoing(true)
            .build()
        startForeground(NOTIFICATION, notification)
        BridgeHolder.start(applicationContext, getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
            .getString(MainActivity.SESSION, "") ?: "", {})
        watchdog.removeCallbacks(watchdogTask)
        watchdog.post(watchdogTask)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == STOP) {
            BridgeHolder.stop()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        watchdog.removeCallbacksAndMessages(null)
        BridgeHolder.stop()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
