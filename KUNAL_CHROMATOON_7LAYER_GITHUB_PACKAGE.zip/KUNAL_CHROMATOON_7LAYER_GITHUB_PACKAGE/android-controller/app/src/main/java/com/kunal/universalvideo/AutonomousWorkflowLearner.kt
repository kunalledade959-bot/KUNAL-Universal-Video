package com.kunal.universalvideo

import android.content.Context
import android.content.pm.PackageManager
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

/**
 * Autonomous target-app discovery.
 *
 * Goal: the controller should discover how a target app exposes a video-making
 * workflow without requiring the user to manually describe every button.
 *
 * Safety:
 * - discovers only observable/help/accessibility evidence
 * - never executes arbitrary code
 * - never assumes an unknown control is correct
 * - every learned action carries evidence and confidence
 * - new workflows are only promoted after verification
 */
object AutonomousWorkflowLearner {
    private const val DIR="guide-knowledge"
    private const val DISCOVERY="discovery.json"
    private const val WORKFLOWS="workflows.json"

    private val videoTerms = setOf(
        "video","story","scene","character","voice","audio","music","timeline",
        "clip","create","generate","render","export","preview","save","project",
        "script","narration","animation","template"
    )

    data class Evidence(
        val text:String,
        val contentDescription:String,
        val viewId:String,
        val className:String,
        val clickable:Boolean,
        val enabled:Boolean,
        val depth:Int
    )

    fun discover(context:Context, packageName:String, root:AccessibilityNodeInfo?): JSONObject {
        val pm=context.packageManager
        val pi=pm.getPackageInfo(packageName,0)
        val label=pm.getApplicationLabel(pm.getApplicationInfo(packageName,0)).toString()
        val evidence=collect(root)
        val ranked=evidence.map { e -> score(e) to e }.filter { it.first>0 }.sortedByDescending { it.first }

        val phases=JSONArray()
        val phaseTerms=listOf(
            "story" to listOf("story","script"),
            "scene" to listOf("scene"),
            "character" to listOf("character"),
            "voice" to listOf("voice","narration"),
            "clip" to listOf("clip","video","generate","create"),
            "timeline" to listOf("timeline","clip","scene"),
            "audio" to listOf("audio","music","voice"),
            "preview" to listOf("preview"),
            "export" to listOf("export","render","save")
        )
        for ((phase,terms) in phaseTerms) {
            val matches=ranked.filter { (_,e) ->
                val s=(e.text+" "+e.contentDescription+" "+e.viewId).lowercase(Locale.US)
                terms.any { s.contains(it) }
            }.take(10)
            phases.put(JSONObject()
                .put("phase",phase)
                .put("matches",JSONArray(matches.map { JSONObject()
                    .put("score",it.first)
                    .put("text",it.second.text)
                    .put("content_description",it.second.contentDescription)
                    .put("view_id",it.second.viewId)
                    .put("clickable",it.second.clickable)
                    .put("enabled",it.second.enabled)
                    .put("depth",it.second.depth)
                    .put("evidence","live_accessibility_ui")
                })))
        }

        val result=JSONObject()
            .put("package",packageName)
            .put("label",label)
            .put("version_name",pi.versionName ?: "unknown")
            .put("discovery_policy","evidence_only_no_guessing")
            .put("evidence_count",evidence.size)
            .put("video_candidates",ranked.size)
            .put("phases",phases)
            .put("next_action","inspect_help_or_safe_ui_path_before_execution")
        val d=File(context.filesDir,DIR).apply{mkdirs()}
        File(d,DISCOVERY).writeText(result.toString(2),Charsets.UTF_8)
        return result
    }

    private fun collect(root:AccessibilityNodeInfo?):List<Evidence>{
        val out=mutableListOf<Evidence>()
        fun walk(n:AccessibilityNodeInfo?,depth:Int){
            if(n==null || depth>40)return
            out += Evidence(
                n.text?.toString() ?: "",
                n.contentDescription?.toString() ?: "",
                n.viewIdResourceName ?: "",
                n.className?.toString() ?: "",
                n.isClickable,
                n.isEnabled,
                depth
            )
            for(i in 0 until n.childCount) walk(n.getChild(i),depth+1)
        }
        walk(root,0)
        return out
    }

    private fun score(e:Evidence):Int{
        val s=(e.text+" "+e.contentDescription+" "+e.viewId).lowercase(Locale.US)
        var score=0
        for(t in videoTerms) if(s.contains(t)) score += if(e.clickable) 3 else 1
        if(e.enabled) score++
        return score
    }

    /**
     * Promote a workflow only after the controller has observed and verified
     * each step. Unknown steps are rejected instead of guessed.
     */
    fun promoteVerifiedWorkflow(context:Context, packageName:String,
                                versionName:String, steps:JSONArray,
                                verification:JSONArray):Boolean{
        if(steps.length()==0 || verification.length()!=steps.length()) return false
        for(i in 0 until steps.length()){
            val step=steps.optJSONObject(i) ?: return false
            if(!step.optBoolean("observed",false) ||
               !step.optBoolean("verified",false) ||
               step.optString("evidence").isBlank()) return false
        }
        val d=File(context.filesDir,DIR).apply{mkdirs()}
        val f=File(d,WORKFLOWS)
        val arr=runCatching{JSONArray(if(f.isFile)f.readText() else "[]")}.getOrDefault(JSONArray())
        arr.put(JSONObject()
            .put("package",packageName)
            .put("version_name",versionName)
            .put("steps",steps)
            .put("verification",verification)
            .put("autonomously_discovered",true)
            .put("promoted_only_after_verification",true))
        f.writeText(arr.toString(2),Charsets.UTF_8)
        return true
    }
}
