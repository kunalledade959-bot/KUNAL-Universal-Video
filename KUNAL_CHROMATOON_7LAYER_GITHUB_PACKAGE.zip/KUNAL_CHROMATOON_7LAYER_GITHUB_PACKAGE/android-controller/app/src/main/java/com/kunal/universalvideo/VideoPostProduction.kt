package com.kunal.universalvideo

import java.io.File

/**
 * Verified post-production coordinator.
 * It produces a deterministic edit plan and refuses to claim a render occurred
 * unless a real output file is subsequently verified.
 */
object VideoPostProduction {
    data class Plan(val clips:List<File>,val audio:File?,val output:File,val operations:List<String>)

    fun plan(clips:List<File>,audio:File?,output:File):Plan {
        require(clips.isNotEmpty()){"NO_VIDEO_CLIPS"}
        clips.forEach { require(it.isFile && it.length()>0){"INVALID_CLIP:${it.name}"} }
        if(audio!=null) require(audio.isFile && audio.length()>0){"INVALID_AUDIO:${audio.name}"}
        return Plan(clips,audio,output,listOf(
            "validate_inputs","trim_or_select_ranges","concatenate_clips",
            "sync_audio","apply_requested_text_or_transitions",
            "render_mp4","verify_mp4","save_to_gallery"))
    }

    fun verifyRenderedVideo(file:File):Boolean =
        file.isFile && file.length()>1024 && file.extension.equals("mp4",true)
}
