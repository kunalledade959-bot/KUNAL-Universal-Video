package com.kunal.universalvideo

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

/**
 * Audio & Asset Intelligence.
 *
 * Finds installed, user-accessible audio/TTS providers and records only what
 * the Android package manager can verify. It does not bypass paid features.
 * Asset selection requires a declared/verified license state.
 */
object AudioAssetIntelligence {
    private const val DIR="guide-knowledge"
    private const val FILE="audio_asset_catalog.json"

    data class Provider(val packageName:String,val label:String,val installed:Boolean,
                        val freeStatus:String,val capability:String)

    private val knownProviders=mapOf(
        "br.com.escolhatecnologia.vozdonarrador" to "Narrator's Voice - TTS",
        "com.speechma.app" to "Speechma - Text to Speech",
        "com.ghosal.realvoice" to "Real Voice Text to Speech"
    )

    fun discoverInstalledProviders(context:Context):JSONObject {
        val pm=context.packageManager
        val providers=JSONArray()
        knownProviders.forEach { (pkg,label) ->
            val installed=runCatching{pm.getApplicationInfo(pkg,0)}.isSuccess
            providers.put(JSONObject()
                .put("package",pkg)
                .put("label",label)
                .put("installed",installed)
                .put("capability","tts/narration")
                .put("free_status","UNKNOWN_UNTIL_FEATURE_LEVEL_IS_VERIFIED")
                .put("policy","use_only_user-accessible_free_features"))
        }
        val result=JSONObject()
            .put("policy","license_verified_assets_only")
            .put("providers",providers)
            .put("fallback_order",JSONArray(listOf(
                "selected_target_free_features",
                "installed_free_tts_provider",
                "verified_local_asset",
                "verified_online_asset",
                "stop_and_report_missing_licensed_asset")))
        val d=File(context.filesDir,DIR).apply{mkdirs()}
        File(d,FILE).writeText(result.toString(2),Charsets.UTF_8)
        return result
    }

    fun chooseBestFreeNarrationCandidate(context:Context, language:String, mood:String):JSONObject {
        val catalog=discoverInstalledProviders(context)
        return JSONObject()
            .put("language",language)
            .put("mood",mood)
            .put("selection_policy","best_quality_among_verified_free_options")
            .put("provider_catalog",catalog)
            .put("requires_runtime_feature_check",true)
    }

    fun recordVerifiedAsset(context:Context, kind:String, source:String,
                            license:String, commercialUse:Boolean) {
        require(kind.isNotBlank() && source.isNotBlank() && license.isNotBlank())
        require(license.lowercase(Locale.US)!="unknown")
        val d=File(context.filesDir,DIR).apply{mkdirs()}
        val f=File(d,"verified_assets.json")
        val a=runCatching{JSONArray(if(f.isFile)f.readText() else "[]")}.getOrDefault(JSONArray())
        a.put(JSONObject().put("kind",kind).put("source",source)
            .put("license",license).put("commercial_use",commercialUse)
            .put("verified_at_ms",System.currentTimeMillis()))
        f.writeText(a.toString(2),Charsets.UTF_8)
    }
}
