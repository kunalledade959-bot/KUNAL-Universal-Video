package com.kunal.universalvideo

object ControllerProtocol {
    const val PROTOCOL = "kunal-video-v1"
    const val PING = "PING"
    const val PONG = "PONG"
    const val OPEN_TARGET = "OPEN_TARGET"
    const val RUN_PLAN = "RUN_PLAN"
    const val STATUS = "STATUS"
    const val EXPORT_READY = "EXPORT_READY"
    const val SAVE_GALLERY = "SAVE_GALLERY"
    const val DISCONNECT = "DISCONNECT"
    const val START_RECORD = "START_RECORD"
    const val STOP_RECORD = "STOP_RECORD"
}
