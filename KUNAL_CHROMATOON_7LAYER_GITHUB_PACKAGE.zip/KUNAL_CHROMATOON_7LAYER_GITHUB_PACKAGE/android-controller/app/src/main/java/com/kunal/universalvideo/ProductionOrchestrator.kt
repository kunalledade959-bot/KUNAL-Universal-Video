package com.kunal.universalvideo

import android.content.Context
import org.json.JSONObject

object ProductionOrchestrator {
    enum class State {
        READY, STORY_EXPANDING, STORY_VERIFIED, TARGET_LEARNING,
        VOICE, MUSIC_SFX, GENERATING, EDITING, RENDERING,
        OUTPUT_VERIFY, GALLERY_SAVE, COMPLETE, FAILED
    }

    fun createPlan(req:StoryCreationEngine.Request):JSONObject {
        val contract=StoryCreationEngine.buildGenerationContract(req)
        return JSONObject().put("state",State.READY.name)
            .put("story_contract",contract)
            .put("phases",org.json.JSONArray(listOf(
                "expand_short_idea","verify_story",
                "learn_target_workflow","discover_free_features",
                "generate_characters_and_actions","generate_narrator_and_dialogue",
                "select_verified_music_and_sfx","generate_clips",
                "record_when_required","edit_trim_join_sync_mix",
                "render","verify_output","save_gallery")))
            .put("stop_on_unverified_state",true)
    }
}
