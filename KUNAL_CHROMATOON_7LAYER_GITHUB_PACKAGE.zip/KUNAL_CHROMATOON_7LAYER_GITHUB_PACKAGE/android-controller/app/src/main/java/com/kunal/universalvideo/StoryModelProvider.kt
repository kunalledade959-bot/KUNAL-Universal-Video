package com.kunal.universalvideo

import android.content.Context
import org.json.JSONObject

object StoryModelProvider {
    interface Provider {
        fun generate(contract:JSONObject):JSONObject
    }

    fun generate(context:Context,contract:JSONObject,provider:Provider?):JSONObject {
        require(provider!=null) { "STORY_MODEL_UNAVAILABLE" }
        val result=provider.generate(contract)
        require(result.optBoolean("complete_story",false)) { "STORY_GENERATION_INCOMPLETE" }
        require(result.has("characters") && result.has("scenes") &&
                result.has("dialogues") && result.has("narration"))
        return result
    }
}
