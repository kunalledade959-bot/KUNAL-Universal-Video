package com.kunal.universalvideo

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.*

class ScreenCaptureService : Service() {
    companion object {
        const val START="START"
        const val STOP="STOP"
        const val CODE="code"
        const val DATA="data"
        private const val CH="kuv_recording"
        private const val NOTIF=8756
        @Volatile private var instance: ScreenCaptureService? = null
        @Volatile private var appContext: Context? = null
        @Volatile private var lastSavedUri: String? = null
        fun hasSavedOutput(): Boolean {
            val value = lastSavedUri ?: return false
            val ctx = appContext ?: return false
            return try {
                val uri = Uri.parse(value)
                ctx.contentResolver.query(uri, arrayOf(MediaStore.Video.Media.SIZE), null, null, null)?.use { c ->
                    if (!c.moveToFirst()) return false
                    val sizeIndex = c.getColumnIndex(MediaStore.Video.Media.SIZE)
                    sizeIndex >= 0 && c.getLong(sizeIndex) > 0L
                } ?: false
            } catch (_: Exception) { false }
        }
        fun isRecording(): Boolean = instance?.recordingStarted == true
        fun stopCurrent(): Boolean {
            val s = instance ?: return false
            if (!s.recordingStarted) return false
            s.stopCapture()
            return true
        }
    }
    private var projection: MediaProjection?=null
    private var display: VirtualDisplay?=null
    private var recorder: MediaRecorder?=null
    private var uri: Uri?=null
    private var outputFd: ParcelFileDescriptor?=null
    private var projectionCallback: MediaProjection.Callback?=null
    private var recordingStarted=false

    override fun onCreate(){super.onCreate();instance=this;appContext=applicationContext;createChannel()}
    private fun createChannel(){val nm=getSystemService(NotificationManager::class.java);if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(NotificationChannel(CH,"Screen recording",NotificationManager.IMPORTANCE_LOW))}

    override fun onStartCommand(i:Intent?,flags:Int,startId:Int):Int{
        when(i?.action){START->startCapture(i);STOP->stopCapture()}
        return START_NOT_STICKY
    }

    private fun startCapture(i:Intent){
        lastSavedUri = null
        if(projection!=null || recorder!=null){cleanup();stopSelf();return}
        val code=i.getIntExtra(CODE,0);val data=if(Build.VERSION.SDK_INT>=33)i.getParcelableExtra(DATA,Intent::class.java) else @Suppress("DEPRECATION") i.getParcelableExtra(DATA)
        if(code==0||data==null){stopSelf();return}
        val notification=NotificationCompat.Builder(this,CH).setContentTitle("Kunal Universal Video").setContentText("Screen recording").setSmallIcon(android.R.drawable.presence_video_online).setOngoing(true).build()
        try{
            if(Build.VERSION.SDK_INT>=29)startForeground(NOTIF,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(NOTIF,notification)
            val pm=getSystemService(MediaProjectionManager::class.java)
            projection=pm.getMediaProjection(code,data)?:throw IllegalStateException("MediaProjection unavailable")
            projectionCallback=object:MediaProjection.Callback(){override fun onStop(){cleanup();stopSelf()}}
            projection!!.registerCallback(projectionCallback!!,Handler(Looper.getMainLooper()))
            val m=resources.displayMetrics;val w=(m.widthPixels.coerceAtMost(1280)/2)*2;val h=(m.heightPixels.coerceAtMost(720)/2)*2
            val name="KunalUniversalVideo_"+SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(Date())+".mp4"
            val v=ContentValues().apply{put(MediaStore.Video.Media.DISPLAY_NAME,name);put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");if(Build.VERSION.SDK_INT>=29){put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/KunalUniversalVideo");put(MediaStore.Video.Media.IS_PENDING,1)}}
            uri=contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,v)?:throw IllegalStateException("MediaStore insert failed")
            outputFd=contentResolver.openFileDescriptor(uri!!,"w")?:throw IllegalStateException("Output FD failed")
            recorder=MediaRecorder().apply{setVideoSource(MediaRecorder.VideoSource.SURFACE);setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);setVideoEncoder(MediaRecorder.VideoEncoder.H264);setVideoEncodingBitRate(5_000_000);setVideoFrameRate(30);setVideoSize(w,h);setOutputFile(outputFd!!.fileDescriptor);prepare()}
            display=projection!!.createVirtualDisplay("KUV",w,h,m.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,recorder!!.surface,null,null)
            if(display==null)throw IllegalStateException("VirtualDisplay creation failed")
            recorder!!.start()
            recordingStarted=true
        }catch(e:Exception){cleanup();stopSelf()}
    }

    private fun stopCapture(){
        var stopped=false
        if(recordingStarted){
            try{recorder?.stop();stopped=true}catch(_:Exception){}
        }
        recordingStarted=false
        if(stopped) {
            finalizeMedia()
            // The MediaStore row is finalized above; prevent onDestroy() from deleting it.
            uri = null
        } else cleanup()
        cleanup(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }
    private fun finalizeMedia(){
        val output = uri ?: return
        try {
            if(Build.VERSION.SDK_INT>=29){
                val updated = contentResolver.update(output, ContentValues().apply{put(MediaStore.Video.Media.IS_PENDING,0)}, null, null)
                if(updated <= 0) throw IllegalStateException("MediaStore finalize failed")
            }
            lastSavedUri = output.toString()
        } catch (_: Exception) {
            try { contentResolver.delete(output, null, null) } catch (_: Exception) {}
            lastSavedUri = null
        }
    }
    private fun cleanup(deleteUri:Boolean=true){recordingStarted=false;try{recorder?.reset()}catch(_:Exception){};try{recorder?.release()}catch(_:Exception){};recorder=null;try{display?.release()}catch(_:Exception){};display=null;projectionCallback?.let{try{projection?.unregisterCallback(it)}catch(_:Exception){}};projectionCallback=null;try{projection?.stop()}catch(_:Exception){};projection=null;try{outputFd?.close()}catch(_:Exception){};outputFd=null;if(deleteUri)uri?.let{try{contentResolver.delete(it,null,null)}catch(_:Exception){}};uri=null}
    override fun onDestroy(){cleanup();instance=null;super.onDestroy()}
    override fun onBind(i:Intent?):IBinder?=null
}
