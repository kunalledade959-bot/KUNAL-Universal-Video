package com.kunal.universalvideo

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileInputStream

object GalleryExporter {
    data class Result(val ok:Boolean,val uri:Uri?,val message:String)

    fun saveMp4(context:Context, source:File, displayName:String):Result {
        if(!source.isFile || source.length()==0L)
            return Result(false,null,"SOURCE_VIDEO_MISSING_OR_EMPTY")
        val safeName=displayName.replace(Regex("[^A-Za-z0-9._-]"),"_")
            .let { if(it.endsWith(".mp4",true)) it else "$it.mp4" }
        return try {
            if(Build.VERSION.SDK_INT>=29) {
                val values=ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME,safeName)
                    put(MediaStore.Video.Media.MIME_TYPE,"video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_MOVIES+"/KunalUniversalVideo")
                    put(MediaStore.Video.Media.IS_PENDING,1)
                }
                val resolver=context.contentResolver
                val uri=resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,values)
                    ?: return Result(false,null,"MEDIASTORE_INSERT_FAILED")
                try {
                    resolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(source).use { input -> input.copyTo(out) }
                    } ?: throw IllegalStateException("MEDIASTORE_OUTPUT_STREAM_FAILED")
                    val done=ContentValues().apply {
                        put(MediaStore.Video.Media.IS_PENDING,0)
                    }
                    resolver.update(uri,done,null,null)
                    Result(true,uri,"SAVED_TO_GALLERY")
                } catch(t:Throwable) {
                    resolver.delete(uri,null,null)
                    Result(false,null,"GALLERY_WRITE_FAILED:${t.javaClass.simpleName}")
                }
            } else {
                val dir=Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_MOVIES).resolve("KunalUniversalVideo")
                if(!dir.exists() && !dir.mkdirs())
                    return Result(false,null,"MOVIES_DIRECTORY_CREATE_FAILED")
                val dst=File(dir,safeName)
                source.inputStream().use { input -> dst.outputStream().use { output -> input.copyTo(output) } }
                context.sendBroadcast(android.content.Intent(
                    android.content.Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,Uri.fromFile(dst)))
                Result(true,Uri.fromFile(dst),"SAVED_TO_GALLERY")
            }
        } catch(t:Throwable) {
            Result(false,null,"GALLERY_EXPORT_FAILED:${t.javaClass.simpleName}")
        }
    }
}
