package com.kunal.universalvideo

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.ConnectivityManager
import android.os.Build
import android.provider.Settings
import android.text.TextUtils
import org.json.JSONArray
import org.json.JSONObject

/**
 * Central capability gate. It never silently bypasses Android consent.
 * Normal permissions are checked; special permissions are detected and
 * the correct system screen/consent flow is surfaced to the user.
 */
object CapabilityManager {
    const val REQ_NOTIFICATIONS = 4101
    const val REQ_MEDIA_PROJECTION = 4102

    data class Capability(
        val id:String, val label:String, val state:String,
        val required:Boolean, val action:String
    )

    fun audit(context: Context): List<Capability> {
        val list=mutableListOf<Capability>()
        list += Capability(
            "internet","Internet","GRANTED",
            true,"none"
        )
        list += Capability(
            "network_state","Network state",
            if (context.checkSelfPermission(Manifest.permission.ACCESS_NETWORK_STATE)==PackageManager.PERMISSION_GRANTED)
                "GRANTED" else "MISSING",
            true,"manifest"
        )
        list += Capability(
            "accessibility","Accessibility control",
            if (isAccessibilityEnabled(context)) "GRANTED" else "USER_ACTION_REQUIRED",
            true,"open_accessibility_settings"
        )
        list += Capability(
            "notification","Notifications",
            if (Build.VERSION.SDK_INT < 33 ||
                context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED)
                "GRANTED" else "USER_ACTION_REQUIRED",
            false,"request_notifications"
        )
        list += Capability(
            "media_projection","Screen capture",
            "USER_ACTION_REQUIRED","true"=="true","request_media_projection"
        )
        list += Capability(
            "target_app","Selected target app",
            if (UniversalAccessibilityService.targetPackage.isNotBlank()) "CONFIGURED" else "USER_ACTION_REQUIRED",
            true,"select_target"
        )
        return list
    }

    fun toJson(context: Context): JSONObject {
        val a=JSONArray()
        audit(context).forEach {
            a.put(JSONObject().put("id",it.id).put("label",it.label)
                .put("state",it.state).put("required",it.required).put("action",it.action))
        }
        return JSONObject().put("capabilities",a)
    }

    fun openAccessibilitySettings(context: Context) {
        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun requestNotifications(activity: Activity) {
        if (Build.VERSION.SDK_INT >= 33)
            activity.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFICATIONS)
    }

    fun requestMediaProjection(activity: Activity) {
        val mgr=activity.getSystemService(MediaProjectionManager::class.java)
        activity.startActivityForResult(mgr.createScreenCaptureIntent(), REQ_MEDIA_PROJECTION)
    }

    private fun isAccessibilityEnabled(context: Context): Boolean {
        val enabled=Settings.Secure.getString(
            context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val expected="${context.packageName}/.UniversalAccessibilityService"
        return enabled.split(':').any { TextUtils.equals(it,expected) }
    }
}
