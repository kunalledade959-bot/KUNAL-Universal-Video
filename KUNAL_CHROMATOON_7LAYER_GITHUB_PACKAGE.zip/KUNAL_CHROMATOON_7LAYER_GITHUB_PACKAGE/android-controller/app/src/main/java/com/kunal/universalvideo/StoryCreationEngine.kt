package com.kunal.universalvideo

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max

/**
 * Converts a SHORT USER IDEA into a deterministic production brief.
 *
 * This is an orchestration contract, not a claim that an on-device LLM exists.
 * A real story model/provider must be supplied at runtime; otherwise the app
 * stops with a precise "STORY_MODEL_UNAVAILABLE" state instead of pretending.
 */
object StoryCreationEngine {
    data class Request(val idea:String,val durationSeconds:Int,val language:String="auto")

    fun validate(req:Request) {
        require(req.idea.trim().length >= 3) { "SHORT_IDEA_TOO_SHORT" }
        require(req.durationSeconds in 15..3600) { "INVALID_DURATION" }
    }

    fun buildGenerationContract(req:Request):JSONObject {
        validate(req)
        val target=max(1,req.durationSeconds)
        return JSONObject()
            .put("input_type","short_idea")
            .put("idea",req.idea.trim())
            .put("language",req.language)
            .put("target_duration_seconds",target)
            .put("must_generate",JSONArray(listOf(
                "complete_story","beginning","conflict","resolution","ending",
                "characters","character_personalities","scenes","dialogues",
                "narration","emotions","character_actions","poses",
                "camera_or_framing","scene_timing","music_plan","sfx_plan",
                "production_timeline")))
            .put("duration_rule","fit_complete_story_to_requested_duration")
            .put("quality_rule","prefer_best_verified_free_target_features")
            .put("failure_rule","never_fabricate_generation_success")
    }

    fun durationBudget(seconds:Int):JSONObject {
        require(seconds>0)
        val narration=max(1,seconds*55/100)
        return JSONObject().put("target_seconds",seconds)
            .put("narration_budget_seconds",narration)
            .put("visual_budget_seconds",seconds)
            .put("audio_mix_budget_seconds",seconds)
    }
}
