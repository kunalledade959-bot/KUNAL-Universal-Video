Kunal Universal Video — hardened repaired project

Source basis: authoritative Master + verified V3 recovery components.
Runtime/build still requires Android toolchain and real-phone verification.


FINAL4: 129 static checks PASS. Runtime/build items remain explicitly unverified.


## Self-Healing Runtime Layer

The Android controller includes `SelfRepairManager`.

It safely repairs recoverable app-private runtime state:
- malformed/invalid session IDs
- stale target-package selection
- missing/corrupt private protocol copy
- missing private repair directories
- stale transient state after a crash
- declared-service/package consistency checks
- bridge-port availability diagnostics
- persistent health report

It does not modify the installed APK, silently enable Accessibility or MediaProjection,
change another app's data, bypass Android security, or claim runtime success without evidence.

## V8 Audio & Asset Intelligence
Discovers installed TTS providers, including Narrator's Voice, without assuming every voice is free. Free-feature selection is verified at runtime; unknown licenses are rejected. Music/SFX assets require recorded license status. The system prefers the best evidenced free option rather than the first working option.
