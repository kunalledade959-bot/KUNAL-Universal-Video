# FINAL ULTRA PACKAGE — SCOPE / TRUTH GATE

## Product layers

1. `android-controller/` — verified Android controller/bridge, Accessibility and MediaProjection components.
2. `web/` — controller web UI plus API and asynchronous video-generation endpoint.
3. `video-engine/` — hardened Wan2.1 story-to-video engine and headless integration core.
4. `master-repaired/` — repaired authoritative project generator.
5. `tools/` — historical verification/recovery/repair utilities retained for recovery, not silently executed.
6. `verification/` — preserved historical verification evidence.

## Historical evidence preserved

- 673 defined atomic project checks: 673/673 PASS.
- 20 repeated rounds of those 673 checks: 13,460/13,460 PASS.
- FINAL11 exhaustive source/static/product suite: 325/325 PASS, 0 FAIL, with 7 documented source repairs.
- FINAL12 fresh deep scan: 192/192 static checks PASS.

## Runtime truth gate

The package does not falsely label physical-device/runtime events as PASS. The following require the actual target environment:

- Android Gradle/AAPT build with Android SDK
- APK installation
- Accessibility runtime enablement
- MediaProjection user consent
- real phone ↔ web/LAN connection
- target-app runtime control
- Wan2.1 model/runtime availability and GPU
- real end-to-end video generation
- real playable 2-minute MP4

## Rule

No known source/static failure is intentionally hidden. If a runtime test fails, use the exact runtime evidence to make the smallest safe repair and rerun the regression suite.
