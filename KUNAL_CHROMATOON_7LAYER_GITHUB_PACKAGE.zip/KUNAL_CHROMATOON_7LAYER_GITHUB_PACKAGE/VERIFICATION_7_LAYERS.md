# 7-Layer Verification Gate

## Layer 1 — Source
- Exact 1→12 sequence
- Original source preserved
- No random replacement

## Layer 2 — Android project
- Gradle files
- Manifest
- Resources
- Dependencies
- Permissions

## Layer 3 — Static audit
- Fake Connected/status-only detection
- Missing implementation detection
- Required classes/components
- Dependency consistency

## Layer 4 — GitHub CI
- Checkout
- Java/JDK 17
- Gradle Wrapper generation + validation
- Gradle build
- Tests
- APK generation
- Artifact upload

## Layer 5 — APK
- APK exists
- APK ZIP structure
- Package/application ID
- Manifest/components
- Artifact SHA-256

## Layer 6 — Runtime
- Install
- Permissions
- Real connection/session
- Chroma Toons selection
- UI observation/action
- Scene creation
- Recording/export
- Final MP4

## Layer 7 — Repeat
- Same 2-minute test multiple runs
- Failure/retry
- Final playback
- Gallery result

## Rule
GitHub build PASS != APK functionality PASS.
A green CI workflow only proves the CI/build gate. Runtime remains separate until real phone evidence exists.
