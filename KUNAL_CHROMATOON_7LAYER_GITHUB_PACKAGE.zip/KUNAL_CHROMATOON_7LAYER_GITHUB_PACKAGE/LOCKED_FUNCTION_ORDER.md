# KUNAL Universal Video — LOCKED 1→12 FUNCTION ORDER

This order is locked and MUST NOT be reordered:

1. APK Startup / Self-Diagnostic
2. Mobile Connection / Permissions
3. Target APK Selection
4. Study Selected APK / Target APK Understanding
5. Story Input
6. Story -> Production Plan / Audio
7. Deep Target-App Understanding / Manual Capability Study
8. Exact Scene-by-Scene Plan
9. Operate Target APK / Automated Video Creation
10. Assemble / Video Editing
11. Verify / Quality Check / Auto-Fix
12. Gallery Export

Ordering constraints:
- Target APK Selection (3) MUST occur before target-app study (4/7).
- Story Input (5) follows target-app study.
- No later block may silently replace or reorder an earlier block.

Source of truth: SOURCE_MASTER.py + KUNAL_UNIVERSAL_VIDEO_MASTER_HANDOFF.md.
