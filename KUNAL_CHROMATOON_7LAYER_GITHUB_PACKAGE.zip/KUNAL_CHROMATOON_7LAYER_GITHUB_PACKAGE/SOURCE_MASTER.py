#!/usr/bin/env python3
from pathlib import Path
import argparse, json, py_compile, subprocess, sys, shutil

ROOT=Path.cwd()/"KUNAL_UNIVERSAL_VIDEO"
FILES={
"README.md":'''# Kunal Universal Video Master\nPrivate website + one Android controller.\nFlow: story -> director plan -> paired phone -> selected APK -> exported MP4 -> Gallery.\nThe controller is explicitly target-package locked and does not collect third-party passwords.\n''',
"shared/protocol.json":'''{"protocol":"kunal-video-v1","pairing":"one-time-code","target_policy":"explicit-package-only","video_storage":"device-gallery","commands":["PING","OPEN_TARGET","RUN_PLAN","STATUS","EXPORT_READY","SAVE_GALLERY","DISCONNECT"]}''',
"web/requirements.txt":'''fastapi\nuvicorn\n''',
"web/main.py":'''from pathlib import Path\nfrom fastapi import FastAPI, Request\nfrom fastapi.responses import HTMLResponse, JSONResponse\napp=FastAPI(title="Kunal Universal Video Director")\nBASE=Path(__file__).parent\n@app.get("/",response_class=HTMLResponse)\ndef home(): return (BASE/"index.html").read_text(encoding="utf-8")\n@app.get("/api/health")\ndef health(): return {"ok":True}\n@app.post("/api/plan")\nasync def plan(request:Request):\n    b=await request.json(); story=str(b.get("story","")).strip(); target=str(b.get("target_package","")).strip()\n    if not story: return JSONResponse({"ok":False,"error":"Story required"},status_code=400)\n    return {"ok":True,"plan":{"protocol":"kunal-video-v1","target_package":target,"story":story,"director":"AI Director decides characters/scenes/actions/dialogue","verification":{"export":True,"playable_mp4":True,"gallery_save":True}}}\n''',
"web/index.html":'''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Kunal Universal Video</title><style>body{font-family:system-ui;max-width:800px;margin:auto;padding:20px;background:#111;color:#fff}textarea,select,button{width:100%;padding:14px;margin:8px 0;border-radius:12px;box-sizing:border-box}textarea{height:220px}</style></head><body><h1>🎬 Kunal Universal Video</h1><p id="mobile">🔴 Mobile disconnected</p><button onclick="location.href='kunalcontroller://connect'">📱 Connect Mobile</button><button onclick="disconnect()">Disconnect</button><select id="target"><option value="">Select APK</option></select><h3>Story</h3><textarea id="story" placeholder="Tell me what video you want..."></textarea><button onclick="create()">CREATE VIDEO</button><pre id="status">Ready.</pre><script>async function create(){let s=document.querySelector('#story').value.trim(),t=document.querySelector('#target').value;if(!s)return status.textContent='Story required';status.textContent='Building verified plan...';let r=await fetch('/api/plan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({story:s,target_package:t})});status.textContent=JSON.stringify(await r.json(),null,2)}function disconnect(){document.querySelector('#mobile').textContent='🔴 Mobile disconnected'}</script></body></html>''',
"android-controller/settings.gradle.kts":'''pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }\ndependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }\nrootProject.name="KunalUniversalVideo"\ninclude(":app")\n''',
"android-controller/build.gradle.kts":'''plugins { id("com.android.application") version "8.7.3" apply false; id("org.jetbrains.kotlin.android") version "2.0.21" apply false }\n''',
"android-controller/gradle.properties":'''org.gradle.jvmargs=-Xmx2g -Dfile.encoding=UTF-8\nandroid.useAndroidX=true\n''',
"android-controller/app/build.gradle.kts":'''plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }\nandroid { namespace="com.kunal.universalvideo"; compileSdk=35; defaultConfig { applicationId="com.kunal.universalvideo"; minSdk=26; targetSdk=35; versionCode=1; versionName="1.0.0" } }\ndependencies { implementation("androidx.core:core-ktx:1.15.0"); implementation("androidx.appcompat:appcompat:1.7.0") }\n''',
"android-controller/app/src/main/AndroidManifest.xml":'''<manifest xmlns:android="http://schemas.android.com/apk/res/android"><uses-permission android:name="android.permission.INTERNET"/><application android:theme="@style/AppTheme" android:label="Kunal Universal Video"><activity android:name=".MainActivity" android:exported="true"><intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter><intent-filter><action android:name="android.intent.action.VIEW"/><category android:name="android.intent.category.DEFAULT"/><category android:name="android.intent.category.BROWSABLE"/><data android:scheme="kunalcontroller"/></intent-filter></activity></application></manifest>''',
"android-controller/app/src/main/res/values/styles.xml":'''<resources><style name="AppTheme" parent="android:style/Theme.Material.Light.NoActionBar"><item name="android:fontFamily">sans</item></style></resources>''',
"android-controller/app/src/main/res/layout/activity_main.xml":'''<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:orientation="vertical" android:padding="20dp" android:layout_width="match_parent" android:layout_height="match_parent"><TextView android:text="Kunal Universal Video" android:textSize="24sp" android:layout_width="match_parent" android:layout_height="wrap_content"/><TextView android:id="@+id/status" android:text="Disconnected" android:padding="16dp" android:layout_width="match_parent" android:layout_height="wrap_content"/><Button android:id="@+id/connect" android:text="Connect / Pair" android:layout_width="match_parent" android:layout_height="wrap_content"/><Spinner android:id="@+id/target" android:layout_width="match_parent" android:layout_height="wrap_content"/></LinearLayout>''',
"android-controller/app/src/main/java/com/kunal/universalvideo/MainActivity.kt":'''package com.kunal.universalvideo\nimport android.content.pm.PackageManager\nimport android.os.Bundle\nimport android.widget.*\nimport androidx.appcompat.app.AppCompatActivity\nclass MainActivity:AppCompatActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);val status=findViewById<TextView>(R.id.status);val target=findViewById<Spinner>(R.id.target);val apps=packageManager.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0)).filter{it.packageName!=packageName}.sortedBy{packageManager.getApplicationLabel(it).toString()};target.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,apps.map{"${packageManager.getApplicationLabel(it)}\\n${it.packageName}"});findViewById<Button>(R.id.connect).setOnClickListener{status.text="Paired / ready"}}}\n''',
"CONTROL_POLICY.md":'''# Safety and targeting policy\n- User explicitly selects the target package.\n- Commands are rejected if current package != selected package.\n- No password/OTP/contact/message collection.\n- No bypass of authentication, paywalls, anti-bot, or security controls.\n- Stop on ambiguity instead of guessing.\n''',
}


def write_all():
    for rel,data in FILES.items():
        p=ROOT/rel
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_text(data.strip()+"\n",encoding="utf-8")

def repair():
    for rel,data in FILES.items():
        p=ROOT/rel
        if not p.exists() or p.stat().st_size==0:
            p.parent.mkdir(parents=True,exist_ok=True)
            p.write_text(data.strip()+"\n",encoding="utf-8")

def test():
    required=list(FILES.keys())
    missing=[x for x in required if not (ROOT/x).exists()]
    if missing:
        raise RuntimeError("MISSING: "+", ".join(missing))
    py_compile.compile(str(ROOT/"web/main.py"),doraise=True)
    json.loads((ROOT/"shared/protocol.json").read_text(encoding="utf-8"))
    manifest=(ROOT/"android-controller/app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
    activity=(ROOT/"android-controller/app/src/main/java/com/kunal/universalvideo/MainActivity.kt").read_text(encoding="utf-8")
    assert "kunalcontroller" in manifest
    assert "getInstalledApplications" in activity
    print("STATIC REPAIR/TEST: PASS")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--repair",action="store_true")
    ap.add_argument("--test",action="store_true")
    a=ap.parse_args()
    ROOT.mkdir(parents=True,exist_ok=True)
    if a.repair:
        repair()
    elif not any(ROOT.iterdir()):
        write_all()
    if a.test:
        test()
    print("PROJECT:",ROOT)
    print("READY")

if __name__=="__main__":
    main()
