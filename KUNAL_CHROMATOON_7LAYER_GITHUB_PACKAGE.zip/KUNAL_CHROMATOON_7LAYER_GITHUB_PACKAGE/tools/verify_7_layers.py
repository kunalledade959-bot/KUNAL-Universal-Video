from pathlib import Path
import hashlib, re, sys, zipfile, json
ROOT=Path(__file__).resolve().parents[1]
fail=[]; notes=[]
def check(name, ok, detail):
    print(f"[{'PASS' if ok else 'FAIL'}] {name} :: {detail}")
    if not ok: fail.append((name, detail))

# Layer 1
master=ROOT/'SOURCE_MASTER.py'
check('L1_MASTER_PRESENT', master.is_file() and master.stat().st_size>0, master)
if master.is_file():
    h=hashlib.sha256(master.read_bytes()).hexdigest()
    check('L1_MASTER_HASH', h=='868f1d2bb621a33267b9a465ff1711570396f312f39f4e0aa579f18d8f1e2f86', h)
spec=(ROOT/'LOCKED_FUNCTION_ORDER.md').read_text()
order=['APK Startup / Self-Diagnostic','Mobile Connection / Permissions','Target APK Selection','Study Selected APK / Target APK Understanding','Story Input','Story -> Production Plan / Audio','Deep Target-App Understanding / Manual Capability Study','Exact Scene-by-Scene Plan','Operate Target APK / Automated Video Creation','Assemble / Video Editing','Verify / Quality Check / Auto-Fix','Gallery Export']
pos=[spec.find(f'{i}. {x}') for i,x in enumerate(order,1)]
check('L1_SEQUENCE', all(x>=0 for x in pos) and pos==sorted(pos), pos)

# Layer 2
req=['settings.gradle.kts','build.gradle.kts','gradle.properties','app/build.gradle.kts','app/src/main/AndroidManifest.xml','app/src/main/res/layout/activity_main.xml','app/src/main/res/xml/accessibility_service_config.xml','app/src/main/java/com/kunal/universalvideo/MainActivity.kt','app/src/main/java/com/kunal/universalvideo/UniversalAccessibilityService.kt','app/src/main/java/com/kunal/universalvideo/ScreenCaptureService.kt','app/src/main/java/com/kunal/universalvideo/LocalBridgeService.kt','app/src/main/java/com/kunal/universalvideo/GalleryExporter.kt']
missing=[x for x in req if not (ROOT/'android-controller'/x).is_file()]
check('L2_REQUIRED_FILES', not missing, missing)
manifest=(ROOT/'android-controller/app/src/main/AndroidManifest.xml').read_text(errors='replace')
for token in ['INTERNET','FOREGROUND_SERVICE','FOREGROUND_SERVICE_MEDIA_PROJECTION','UniversalAccessibilityService','ScreenCaptureService']:
    check('L2_MANIFEST_'+token, token in manifest, token)

# Layer 3
activity=(ROOT/'android-controller/app/src/main/java/com/kunal/universalvideo/MainActivity.kt').read_text(errors='replace')
bridge=(ROOT/'android-controller/app/src/main/java/com/kunal/universalvideo/LocalBridgeService.kt').read_text(errors='replace')
# Reject status-only connected/paired claims. Actual bridge is allowed.
fake=bool(re.search(r'setOnClickListener\s*\{\s*status\.text\s*=\s*["\'](?:Connected|Paired / ready|Controller ready)',activity,re.I|re.S))
check('L3_NO_FAKE_CONNECTED', not fake, 'status-only connected handler' if fake else 'no direct fake Connected/Paired handler')
for token in ['ServerSocket','/health','/pair','/command','authToken','PING','PONG','DISCONNECT']:
    check('L3_REAL_TRANSPORT_'+token, token in bridge, token)
for f,toks in {
 'UniversalAccessibilityService.kt':['AccessibilityService','onAccessibilityEvent'],
 'ScreenCaptureService.kt':['MediaProjection','MediaProjectionManager'],
 'GalleryExporter.kt':['MediaStore','.mp4'],
}.items():
    txt=(ROOT/'android-controller/app/src/main/java/com/kunal/universalvideo'/f).read_text(errors='replace')
    check('L3_'+f, all(t in txt for t in toks), toks)

# Layer 4 CI prep
wf=ROOT/'.github/workflows/android-apk.yml'
check('L4_GITHUB_WORKFLOW', wf.is_file(), wf)
if wf.is_file():
    w=wf.read_text()
    for t in ['actions/checkout@v4','actions/setup-java@v4','java-version: \'17\'','gradle/actions/setup-gradle@v4','gradle wrapper','./gradlew', 'assembleDebug','upload-artifact@v4']:
        check('L4_'+t.replace('/','_'), t in w, t)

# Layer 5 is only PASS if an APK artifact exists; source package cannot fake it.
apks=list(ROOT.rglob('*.apk'))
check('L5_APK_EXISTS', bool(apks), [str(x) for x in apks])
if apks:
    for apk in apks:
        try:
            with zipfile.ZipFile(apk) as z:
                names=set(z.namelist())
            check('L5_APK_STRUCTURE_'+apk.name, 'AndroidManifest.xml' in names and 'classes.dex' in names, apk)
        except Exception as e: check('L5_APK_ZIP_'+apk.name, False, e)

# Runtime remains explicitly unverified here.
print('\nRUNTIME_STATUS=UNVERIFIED')
print('Layer 6/7 require a real phone session and repeated 2-minute Chroma Toons evidence.')
if fail:
    print('\nSTATIC_RESULT=FAIL')
    for n,d in fail: print(' -',n,d)
    sys.exit(1)
print('\nSTATIC_RESULT=PASS')
