# Safety and targeting policy
- User explicitly selects the target package.
- Commands are rejected if current package != selected package.
- No password/OTP/contact/message collection.
- No bypass of authentication, paywalls, anti-bot, or security controls.
- Stop on ambiguity instead of guessing.
