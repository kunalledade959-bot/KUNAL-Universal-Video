from __future__ import annotations

import importlib.util
import threading
import time
import traceback
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse

BASE = Path(__file__).parent
ROOT = BASE.parent
ENGINE = ROOT / "video-engine" / "core.py"
OUTPUT_ROOT = Path("/kaggle/working/PRO_ULTRA_PROJECTS")

app = FastAPI(title="Kunal Universal Video Director")

_executor = ThreadPoolExecutor(max_workers=1)
_job_lock = threading.Lock()
_jobs: dict[str, dict] = {}
_engine_lock = threading.Lock()
_engine_module = None
_engine_error = None


def _load_engine():
    """Lazy-load the real video engine so controller health works without a GPU/model."""
    global _engine_module, _engine_error
    with _engine_lock:
        if _engine_module is not None:
            return _engine_module
        if _engine_error is not None:
            raise RuntimeError(_engine_error)
        if not ENGINE.is_file():
            _engine_error = f"Video engine missing: {ENGINE}"
            raise RuntimeError(_engine_error)
        try:
            spec = importlib.util.spec_from_file_location("kuv_video_engine", ENGINE)
            if spec is None or spec.loader is None:
                raise RuntimeError("Could not create video-engine loader")
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            _engine_module = module
            return module
        except Exception as exc:
            _engine_error = f"Video engine unavailable: {type(exc).__name__}: {exc}"
            raise RuntimeError(_engine_error) from exc


def _set_job(job_id: str, **values):
    with _job_lock:
        _jobs.setdefault(job_id, {}).update(values)


def _run_video_job(job_id: str, payload: dict):
    _set_job(job_id, status="starting", started_at=time.time())
    try:
        engine = _load_engine()
        _set_job(job_id, status="running")
        final_video, message = engine.generate_project(
            payload["story"],
            payload.get("mode", "Cartoon"),
            payload.get("character_description", "original fictional character"),
            int(payload.get("seed", 12345)),
            payload.get("voice", "hi-IN-SwaraNeural"),
            None,
        )
        if not final_video:
            _set_job(job_id, status="failed", error=str(message), finished_at=time.time())
            return
        path = Path(final_video)
        if not path.is_file() or path.stat().st_size <= 0:
            _set_job(job_id, status="failed", error="Engine returned no valid final MP4", finished_at=time.time())
            return
        _set_job(
            job_id,
            status="complete",
            final_video=str(path),
            message=str(message),
            finished_at=time.time(),
        )
    except Exception:
        _set_job(job_id, status="failed", error=traceback.format_exc()[-12000:], finished_at=time.time())


@app.get("/", response_class=HTMLResponse)
def home():
    return (BASE / "index.html").read_text(encoding="utf-8")


@app.get("/api/health")
def health():
    return {
        "ok": True,
        "protocol": "kunal-video-v1",
        "video_engine": ENGINE.is_file(),
        "video_engine_runtime": "lazy" if ENGINE.is_file() else "missing",
    }


@app.get("/api/video/capabilities")
def video_capabilities():
    result = {
        "ok": ENGINE.is_file(),
        "engine_file": str(ENGINE),
        "runtime_checked": False,
        "generation": "available_after_runtime_check" if ENGINE.is_file() else "unavailable",
    }
    return result


@app.post("/api/plan")
async def plan(request: Request):
    body = await request.json()
    story = str(body.get("story", "")).strip()
    target = str(body.get("target_package", "")).strip()
    if not story:
        return JSONResponse({"ok": False, "error": "Story required"}, status_code=400)
    if len(story) > 20000:
        return JSONResponse({"ok": False, "error": "Story too long (max 20000 characters)"}, status_code=400)
    if not target:
        return JSONResponse({"ok": False, "error": "Target package required"}, status_code=400)
    return {
        "ok": True,
        "plan": {
            "protocol": "kunal-video-v1",
            "target_package": target,
            "story": story,
            "director": "PRO-ULTRA Wan2.1 scene/video engine",
            "steps": [{"action": "open_target"}, {"action": "wait_ms", "value": 1000}],
            "verification": {
                "export": "ENGINE_VALIDATES_MP4",
                "playable_mp4": "ENGINE_VALIDATES_VIDEO_AND_AUDIO",
                "gallery_save": "PHONE_RUNTIME_REQUIRED",
            },
        },
    }


@app.post("/api/video/start")
async def start_video(request: Request):
    body = await request.json()
    story = str(body.get("story", "")).strip()
    if not story:
        return JSONResponse({"ok": False, "error": "Story required"}, status_code=400)
    if len(story) > 20000:
        return JSONResponse({"ok": False, "error": "Story too long (max 20000 characters)"}, status_code=400)
    mode = str(body.get("mode", "Cartoon"))
    if mode not in {"Cartoon", "Real AI", "Hybrid"}:
        return JSONResponse({"ok": False, "error": "Invalid character mode"}, status_code=400)
    job_id = uuid.uuid4().hex
    payload = {
        "story": story,
        "mode": mode,
        "character_description": str(body.get("character_description", "original fictional character")),
        "seed": int(body.get("seed", 12345)),
        "voice": str(body.get("voice", "hi-IN-SwaraNeural")),
    }
    _set_job(job_id, status="queued", created_at=time.time())
    _executor.submit(_run_video_job, job_id, payload)
    return {"ok": True, "job_id": job_id, "status": "queued"}


@app.get("/api/video/status/{job_id}")
def video_status(job_id: str):
    with _job_lock:
        job = dict(_jobs.get(job_id, {}))
    if not job:
        return JSONResponse({"ok": False, "error": "Unknown job"}, status_code=404)
    return {"ok": True, "job_id": job_id, **job}


@app.get("/api/video/result/{job_id}")
def video_result(job_id: str):
    with _job_lock:
        job = dict(_jobs.get(job_id, {}))
    if not job:
        return JSONResponse({"ok": False, "error": "Unknown job"}, status_code=404)
    if job.get("status") != "complete":
        return JSONResponse({"ok": False, "status": job.get("status"), "error": job.get("error")}, status_code=409)
    path = Path(job["final_video"])
    if not path.is_file():
        return JSONResponse({"ok": False, "error": "Final MP4 disappeared"}, status_code=410)
    return FileResponse(path, media_type="video/mp4", filename="Kunal_Universal_Video.mp4")
