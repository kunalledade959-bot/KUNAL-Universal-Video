# Build route

Primary verification route: GitHub Actions.
Fallback cloud route: Codemagic.

The package deliberately separates CI/build PASS from real phone/runtime PASS.
The current Android source already contains a real local bridge implementation and
Accessibility/MediaProjection/Gallery components, but a real Chroma Toons run and
2-minute MP4 have not been claimed here without device evidence.

Do not delete or reorder the 1→12 sequence. Do not replace source files with blank stubs.
